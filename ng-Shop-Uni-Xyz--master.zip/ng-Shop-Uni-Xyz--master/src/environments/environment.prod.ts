export const environment = {
  production: true,
  firebase: {
    apiKey: "AIzaSyBVZyccddVuojN7xoIgPAsVbQ3WTHpnAAE",
    authDomain: "xyz-uni.firebaseapp.com",
    databaseURL: "https://xyz-uni.firebaseio.com",
    projectId: "xyz-uni",
    storageBucket: "xyz-uni.appspot.com",
    messagingSenderId: "243551109466",
    appId: "1:243551109466:web:af4400eac17c403b"
  }
};
